import pandas as pd
import numpy as np
from itertools import product, cycle, islice


def roundrobin(*iterables):
    "roundrobin('ABC', 'D', 'EF') --> A D E B F C"
    # Recipe credited to George Sakkis
    num_active = len(iterables)
    nexts = cycle(iter(it).__next__ for it in iterables)
    while num_active:
        try:
            for next in nexts:
                yield next()
        except StopIteration:
            # Remove the iterator we just exhausted from the cycle.
            num_active -= 1
            nexts = cycle(islice(nexts, num_active))

def compute_centroid_euclidian_distance(p):

    punkte = len(p)
    xs = p[::2]
    ys = p[1::2]

    cx = np.mean(xs)
    cy = np.mean(ys)
    print(cx)
    print(cy)
    mittelwerte = np.array([cx, cy])

    points = list(zip(xs, ys))
    print(points)

    # Calculate Euclidean distance for each data point assigned to centroid
    distances = [np.sqrt((x - cx) ** 2 + (y - cy) ** 2) for (x, y) in points]
    # return the mean value
    return np.mean(distances)



dateiname = 'C:\\python\\data\\celbah_py_2018-03-14 17-42-33.247000.txt'

df = pd.read_csv(dateiname)

coord = eval(df.MemColor[0])
#print(coord)
xs = coord[0]
ys = coord[1]
p = list(roundrobin(xs, ys))
#print(p)
print('Centroid Euclidian Distance: ', compute_centroid_euclidian_distance(p))

