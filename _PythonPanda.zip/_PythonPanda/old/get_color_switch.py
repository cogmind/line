'''
Author: Carina Rose, Daniel Labbé
Date: 2018-05-22

Analyze der Behavorialen Daten
'''

import pandas as pd
import numpy as np

def convert2color_switch_series(mem_colors, test_colors, cues):
    
    color_switches = []

    for row, _ in enumerate(mem_colors):

        print(row)
        #print(cues)
        c = cues.iat[row]
        print(c)

        if c == 'left':
            cue = 0
        elif c == 'right':
            cue = 1
        else:
            print('WARNING: No left or right cue')

        mem_color = eval(mem_colors.iat[row])
        test_color = eval(test_colors.iat[row])

        #print(mem_color)
        #print(test_color)
        for m, t in zip(mem_color[cue], test_color[cue]):
            if not m == t:
                target = t
                color = m

        color_switches.append(color + target)

    return color_switches

    original_colors, target_colors = mem_colors.map(eval), test_colors.map(eval)
    #print(colors_df.MemCoord, '-----------------', colors_df.TestColor)
    cue = cues.isin(['right'])

    targets = []
    originals = []

    for mem_color, test_color, c in zip(mem_colors, test_colors, cue):

        target = list(set(mem_color[c]) - set(test_color[c]))
        original = list(set(test_color[c]) - set(mem_color[c]))
        targets.append(target)
        originals.append(originals)

    print('-----------TARGET-----------')
    print(targets)
    print('-----------ORIGINAL-----------')
    print(originals)





    return target


print('Analyze der Behavorialen Daten')
print(60 * '-')

#dateiname = 'C:\\python\\celbah_py_2018-03-14 17-42-33.247000.py'
dateiname = 'D:\\analysis\\pomo\\_PythonPanda\\data\\celbah_py_2018-03-14 17-42-33.247000.txt'

df = pd.read_csv(dateiname)#, usecols=['ID', 'Age', 'Gender', 'Trial', 'Items', 'Match', 'Response', 'RT'])

response = ['HIT', 'MISS', 'CR', 'FA']
item = [2, 3, 4, 5]

hits = []
misses = []
cr = []
fa = []

response_output = dict(zip(response, [hits, misses, cr, fa]))

print(response_output)

for r in response:
    for i in item:
        item_response = df.loc[:, 'Response'].loc[
            (df.loc[:, 'Response'] == r) &
            (df.loc[:, 'Items'] == i)
        ]
        response_output.get(r).append(item_response)

df_K = pd.DataFrame.from_dict(response_output)
TWO = 0
THREE = 1
FOUR = 2
FIVE = 3


# TODO
# 1. Compute Cowan's K per Item per Subject
#       Merge DataFrames and populate Subject Index
# 2. Color Switch Analysis:
#       Dummy coding für CR FA
#       Prepare output suitable for SPSS (bypass Excel), alternativ: Analyze in Python, mit z.B. Heatmaps in MatplotLib
# 



#hit_items = df.HIT[TWO].append(df.HIT[THREE], df.HIT[FOUR], df.HIT[FIVE])
#print(hit_items)


df_colors = df

non_match = df_colors[df_colors['Match'] == 'non-match']

#print(non_match)



#convert2color_switch(non_match)
#print(convert2color_switch('[(\'RED\', \'GREEN\'), (\'RED\', \'BLACK\')]'))

non_match['ColorSwitch'] = convert2color_switch_series(non_match.MemCoord, non_match.TestColor, non_match.Cue)

df['ColorSwitch'] = non_match['ColorSwitch']
print(df)
grouped = df.groupby('ColorSwitch')

print(grouped['RT'].agg([np.mean, np.std, np.median]))

non_match['CR'] = pd.get_dummies(non_match.Response)['CR']
non_match['FA'] = pd.get_dummies(non_match.Response)['FA']

print(non_match.groupby(['CR', 'ColorSwitch']).agg({'CR': np.sum, 'FA': np.sum, 'RT': [np.mean, np.std, np.median]}))



#print(non_match)
#print(non_match)


#non_match.lookup('MemCoord')
#print(non_match)















#print(df)
#print(df.HIT)


#alle_hits = alle_hits.count()
#print(alle_hits)

#alle_FAs = df.loc[:, 'Response'].loc[df.loc[:, 'Response'] == 'FA']
#print(alle_FAs.count())
