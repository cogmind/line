'''
Verfasser: Carina Rose, Daniel Labbe
Datum: 2018-05-22

Analyze der Behavorialen Daten
'''

import pandas as pd
from os import getcwd
import matplotlib.pyplot as plt
import numpy as np
import path

def compute_CowansK(pre_CowansK, item):

	hit_rate = pre_CowansK.loc[item, 'HIT'] / (pre_CowansK.loc[item, 'HIT'] + pre_CowansK.loc[item, 'MISS'])
	cr_rate = pre_CowansK.loc[item, 'CR'] / (pre_CowansK.loc[item, 'CR'] + pre_CowansK.loc[item, 'FA'])

	return item * (hit_rate + cr_rate - 1)

def compute_within_subject(dateiname):

	df = pd.read_csv(dateiname, usecols=['ID', 'Age', 'Gender', 'Trial', 'Items', 'Match', 'Response', 'RT'])

	response = ['HIT', 'MISS', 'CR', 'FA']
	item = [2, 3, 4, 5]

	pre_CowansK = df.groupby(['Items', 'Response'])['Response'].count()
	print(pre_CowansK)

	k = []
	for i in item:
			k.append(compute_CowansK(pre_CowansK, i))

	print(k)


print('Analyze der Behavorialen Daten')
print(60 * '-')
current_dir = 'D:\\analysis\\pomo\\_PythonPanda\\CowansK_version2_0\\'
current_dir = current_dir is '' and getcwd() or current_dir
current_dir = current_dir + path.sep + 'data' + path.sep
print(current_dir + '\\n')


f = [] # Stackoverflow Recipe
for (dirpath, dirname, filename) in walk(current_dir):
    f.extend(filename)
    break

files = pd.Series(f)
printmd('### Files')
print(files)
printmd('### Subjects')
print(*[file[0:6] for file in files])

iter_files = iter(f) #np.nditer(f)

for filename in iter_files:
	print('Current file is {}...'.format(filename))
	filename = path.join(current_dir, filename)
	compute_within_subject(filename)
	print(60 * '-')

y = k
x = np.arange(2, 6)
print(x)
print(y)

# Plot by item for each individual
fig, ax = plt.subplots()
y2 = [(yy + 1) for yy in y]
plt.plot(x, y, x, y2) # BEISPIEL
plt.ylabel('Cowan\'s K')
plt.minorticks_off()
#plt.set(xlabel='Items', ylabel='Cowan\'s K',
#       title='Cowan\'s K')

plt.show()



