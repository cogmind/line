import numpy as np
import numpy.ma as ma
import pandas as pd
import fnmatch
import inspect
import code
from sys import version
from os import getcwd, path, walk

CSL_LINES = 40
print(CSL_LINES * '>>>')
assert (int(version[0][0]) > 2 or '__future__' in sys.modules) # Version number >2 affects float division. See also PYTHON command line option -Q <arg>
print(version)

print('Behavioral Data Analysis', 'Cowan\'s K, Response Times, etc.', version, CSL_LINES * '=',)

''' Prepare Data for Import '''
current_dir = getcwd() + path.sep + 'data' + path.sep
print('Current directory is ' + current_dir + '\n')

f = [] # Stackoverflow Recipe
for (dirpath, dirname, filename) in walk(current_dir):
    f.extend(filename)
    break
    
files = pd.Series(f)
print(files)

# Initialize Data Accumulation
iter_files = iter(f) #np.nditer(f)

# TODO WARNING Notice the error of the header for coordinates and colors
#
#
#
#

items = [2, 3, 4, 5]
data_trials = [] 
data_hits = []
data_fa = []
data_ck = []


for filename in iter_files:

	print('_' * CSL_LINES)
	print('Current file is {}...'.format(filename))
	filename = path.join(current_dir, filename)
	data = np.genfromtxt(
		filename,
		dtype = None,
		names = True,
		delimiter = ',',
		missing_values = (999999),
		usecols = (1,2,4,5,6,7,8,9,10) # TODO Ignoring stimulus data for now
	)

	d = data.ndim
	data = np.reshape(data,(data.size, 1))

	print('Dim reshaped from {} to {}'.format(d, data.ndim))

	# Print the first 4 rows
	#print('File Preview: ')
	#print(data[0:4])

	print(CSL_LINES * '-')
	# Remove illegal responses
	l = len(data)
	data = data[data['RT'] < 7000]
	#print(data)
	print('Missing Values Removed: {}'.format(l - len(data)))
	#print(data[0:4])
	print(CSL_LINES * '^')

	# Compute Signal Detection Theory (SDT) measures
	print('Level: Subject')
	r = data['Response']
	print('{} responses'.format(len(r)))
	hit = len(r[r == b'HIT'])
	miss = len(r[r == b'MISS'])
	fa = len(r[r == b'FA'])
	cr = len(r[r == b'CR'])
	total = hit + miss + fa + cr
	assert len(r) == total

	print('Total Valid Trials {}'.format(total))


	data_trials.append(total)

	hitrate = 100 * hit / total
	farate = 100 * fa / total

	data_hits.append(hitrate)
	data_fa.append(farate)

	print('Hits: {}\nMisses: {}\nFalse Alarms: {}\nCorrect Responses: {}'.format(hit,miss,fa,cr))

	# Rounding
	decimals = 2

	print('Hit{2}: {0}%\nFalse Alarm{2}: {1}%\n[of valid responses]'.format(round(hitrate, decimals),round(farate, decimals),'rate'))

	print('Level: Per Item in Subject')
	print('Items: {}'.format(items))

	#  Compute Cowan's K for all items
	 
	data = pd.DataFrame(data)

#	print(data)

	'''TODO Groupby Subject ID... Accumulate'''
	responses = data.groupby(['Items', 'Response']) # Yeah, I know it's Hungarian notation, because intuitively one would expect that pandas returned a dataframe
	responses = responses.size()




	# For each item get total and individual SDT values


	#agg_responses_per_items.loc[:,['CR']]
	#ai = np.nditer(a, flags=['multi_index'])
	# no clue what setting this flag or not does. preserves multi_index? #ainoflag = np.nditer(a)

	# Helper function
	fun = lambda x: np.asarray(x)

	#
	# Signal Detection Measures
	#
	#
	#
	#


	#totali = fun([sum(responses.loc[i,:]) for i in items])

	totali = hi = fai = cri = mi = []

	hi = fun([responses.loc[:, b'HIT']])
	fai = fun([responses.loc[:, b'FA']])
	cri = fun([responses.loc[:, b'CR']])
	mi = fun([responses.loc[:, b'MISS']])
	totali = [np.sum(hi), np.sum(fai), np.sum(cri), np.sum(mi)]
	totali = fun(totali)


	decimals = 2
	N = fun(items)


	responses = pd.DataFrame(responses)

	for i in items:
	#	i = str(i)
		totali = hi = fai = cri = mi = []

	#		i = eval('b\'' + str(item))

	try:
		hi = responses[0][i][b'HIT']
	except:
		hi = []
	try:
		fai = responses[0][i][b'FA']
	except:
		fai = []
	try:
		cri = responses[0][i][b'CR']
	except:
		cri = []
	try:
		mi = responses[0][i][b'MISS']
	except:
		mi = []

	hi = fun(hi)
	fai = fun(fai)
	totali = np.sum(hi) + np.sum(fai)# + np.sum(cri) +np.sum(mi)

#		print(responses.loc(responses['Response']))

	#		fai = fun([responses.loc['Response']['FA'] & responses.loc['Items' == i]])
		#cri = fun([responses.get['Response'] == 'CR' & responses.at['Items'] == i])
		#mi = fun([responses.get['Response'] == 'MISS' & responses.at['Items'] == i])
		#totali = [np.sum(hi), np.sum(fai), np.sum(cri), np.sum(mi)]
	totali = fun(totali)
	print('ih fi totali')
	print(hi)
	print(fai)
	print(totali)
	data_ck.append(np.round( ( (N * (hi - fai)) / totali ), decimals))

		

	# Debug Entry.
	#code.interact(local=locals())
	# Move this line around to debug the variable "workspace"



	# Rounding precision
#	decimals = 2 

	# False Alarm Rate (False Positive Rate)
	# NTS: Might be iteresting to look at the ratios here... assuming the limit corresponds to a quanta - i.e. a limited resource (limes being the quantum) - that can be partially distributed....
	#print('FAs: {}'.format(np.round(fai / totali * 100, decimals)))


	# The original
	# (H + CR - 1) * N

	# Vector of items
#	N = fun(items)

'''
	try:
		# Because we had fun, we can by means of symbolical math compute Cowan's K thus
		ck1 = np.round( ( (hi + cri - 1) / totali ), decimals)

		print('N, hi, fai, totali, decimals, cri')
		print(N, hi, fai, totali, decimals, cri)

		ck2 = np.round( ( N * (hi - fai) / totali ), decimals)
		k_zero = np.round( (ck1 + ck2) / 2 , decimals)
		global_total = sum(totali)

	except e:
		print('Exception ', e)
		fai = fai[0]
		totali = totali[0]
		cri = cri[0]
		ck2 = np.round( ( N * (hi - fai) / totali ), decimals)
		k_zero = np.round( (ck1 + ck2) / 2 , decimals)
		global_total = sum(totali)



		# Stratified samples of n trials weighted by evidence per item
		# Compute the item percentage of the total sample
		strata_weights = totali / global_total
		# Compute the mean percentage
		mean_weight = np.mean(strata_weights)
		# Center the weights around the mean percentage by subtracting the mean
		mean_centered_weights = strata_weights - mean_weight

		print(strata_weights)
		print(mean_centered_weights)
		ck_error = 1 - (ck1 + ck2) / 2

		new_weights = mean_centered_weights + 1
		print(new_weights)


		# Just checking if using numpy results in 32-bit mess or if 64bit precision is kept.
		# Great. Test passed.
		#print('{}{}'.format(type(new_weights[0]), type(strata_ck1[0])))

		# Finally, weigh Cowan's k+ and k-
		strata_ck1 = np.round(new_weights * ck1, decimals)
		strata_ck2 = np.round(new_weights * ck2, decimals)

		# For each item
		ones = fun(len(items) * [1])

		#lk_error = (ck2 - ck1) / 2

		# Print debug information
		print('Per Item (2, 3, 4, 5)')
		print('Total: {}\nHits: {}\nFalse Alarms: {}'.format(totali, hi, fai))
		print('Cowan''s k+: {}'.format(ck1))
		print('Cowan''s k-: {}'.format(ck2))
		print('Cowan''s k0: {}'.format(k_zero))
		print(CSL_LINES * '#')
		print('{}{}{}{}{}{}'.format(ck1, ck2, k_zero, ck_error, strata_ck1, strata_ck2))
		print(CSL_LINES * '#')
		print('k error: {}'.format(ck_error))
		print('k+ weighted by coefficents (stratified sampling): {}'.format(strata_ck1)) # NTS tratified might not be the most accurate term here
		print('k- weighted by coefficents (stratified sampling): {}'.format(strata_ck2))

		#### TO DO .... FIX THIS Read the pandas manual
	#	big_data = pd.DataFrame(data=[ck1, ck2, k_zero, ck_error, strata_ck1, strata_ck2])
	#	next_data = pd.DataFrame(data=[ck1, ck2, k_zero, ck_error, strata_ck1, strata_ck2])
	#	big_data = pd.DataFrame.append(big_data, next_data)

'''

print('All files processed.', CSL_LINES*'-', 'Results',)
#big_data.T

[print(i) for i in data_trials]
[print(i) for i in data_hits]
[print(i) for i in data_fa]

print('Cowan\'sK')
[print(ck) for ck in data_ck]
