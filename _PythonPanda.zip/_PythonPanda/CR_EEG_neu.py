import numpy as np
import pandas as pd

dateiname = 'C:\\python\\CDA2017.csv'
df = pd.read_csv(dateiname)

print(df)

x = df.loc[:, 'Two']
y = df.loc[:, 'Three']
z = df.loc[:, 'Four']
p = df.loc[:, 'Five']

mean_two = np.mean(x)
mean_three = np.mean(y)
mean_four = np.mean(z)
mean_five = np.mean(p)
print(mean_two, mean_three, mean_four, mean_five)