
#Dash Dot Plot (etframes):


from numpy.random import *
from pylab import *

from lib import etframes


ys = [normal() for _ in range(100)]
xs = [normal() for _ in range(100)]

scatter(xs,ys)

etframes.add_dot_dash_plot(gca(), ys=ys, xs=xs)


show()






#1. change colors from defaults to chosen ones
x = np.linspace(0, 1, 10)
fig, ax = plt.subplots()
ax.set_color_cycle(['red', 'black', 'yellow'])
for i in range(1, 6):
    plt.plot(x, i * x + i, label='$y = {i}x + {i}$'.format(i=i))
plt.legend(loc='best')
plt.show()

#2. change colors in a specified order (?)

import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 1, 10)
for i, color in enumerate(['red', 'black', 'blue', 'brown', 'green'], start=1):
    plt.plot(x, i * x + i, color=color, label='$y = {i}x + {i}$'.format(i=i))
plt.legend(loc='best')
plt.show()


#3. select a specified number of colors from an existing colormap:

import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 1, 10)
number = 5
cmap = plt.get_cmap('viridis')
colors = [cmap(i) for i in np.linspace(0, 1, number)]

for i, color in enumerate(colors, start=1):
    plt.plot(x, i * x + i, color=color, label='$y = {i}x + {i}$'.format(i=i))
plt.legend(loc='best')
plt.show()






#font size :

#import matplotlib as mpl
#mpl.rcParams.update({'font.size': 12})


