#utils::example(SSD)
library("feather")
print("D:/analysis/pomo/_PythonPanda/BehavioralAnalysis/feather/temp_subject.feather")
df <- feather("D:/analysis/pomo/_PythonPanda/BehavioralAnalysis/feather/temp_subject.feather")
df <- data.frame(df)
# Age Gender Trial Items     Match   Cue   RT Response
df <- within(df, rm("MemCoord", "MemColor", "TestColor"))

df$Gender <- as.factor(df$Gender)
df$Match <- as.factor(df$Match)
df$Cue <- as.factor(df$Cue)
df$Response <- as.factor(df$Response)

df <- aggregate(df, df["Items"], mean)

mlmfit <- 0
mlmfit <- lm(matrix(df$RT, df$Trial) ~ df$Items, df)


mlmfit0 <- update(mlmfit, ~0)
print(mauchly.test(mlmfit, X=~1))
print(mauchly.test(mlmfit0, X=~1))
