import numpy as np

def confidence_interval(x, sd, confidence, n):
	'''
	Computes the confidence interval given a known standard deviation

	x Mean
	confidence_level Percentage, one of 99, 98, 95, or 90. Looks up a z-star value from table.
	n Sample size
	sd Standard deviation
	'''
	bound = confidence * (sd / np.sqrt(n))

	ci_lower = x - bound
	ci_upper = x + bound

	return [ci_lower, ci_upper]

'''
confidence_level = {
						99: 2.58,
						98: 2.326,
						95: 1.96,
						90: 1.645
}

level = 95
x = 2.0
sd = 1.0
confidence = confidence_level[level]
n = 12

print('CI(' + str(level) + '): ' + str(confidence_interval(x, sd, confidence, n)))
'''