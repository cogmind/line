import matplotlib.pyplot as plt
import numpy as np

def confidence_interval(x, sd, confidence, n):
	'''
	Computes the confidence interval given a known standard deviation

	x Mean
	confidence_level Percentage, one of 99, 98, 95, or 90. Looks up a z-star value from table.
	n Sample size
	sd Standard deviation
	'''
	bound = confidence * (sd / np.sqrt(n))

	ci_lower = x - bound
	ci_upper = x + bound

	return [ci_lower, ci_upper]

def plot_figure(x_start, y, xlabel, ylabel, error = None):

	x = lambda y: range(x_start, len(y) + x_start)

	SLOPE, INTERCEPT = np.polyfit(x(y), y, 1)
	
	black_diamonds = 'kD-' #  Black dimanond solid line
	red_line = 'r-'

	if error is not None:
		plt.errorbar(x(y), y, yerr=error, fmt=black_diamonds)
	else:
		plt.plot(x(y), y, black_diamonds)


	print(SLOPE, INTERCEPT)

	fit_line = True #  Toggle
	if fit_line:
		plt.plot(x(y), SLOPE * np.array(x(y)) + INTERCEPT, fmt=red_line)

	plt.ylabel(ylabel)
	plt.xlabel(xlabel)

	plt.show()


# Figure 1

# TODO UPDATE Y DATA and standard deviation!!!!!
y = [0.1, 0.2, 0.3, 0.4, -0.5, -1.2, 5.0, 0.0]
sd = [0.01, 0.002, 0.03, 0.01, 0.05, 0.0025, 0.01, 0.029]
x_start = 4
ylabel = 'Amplitude (${\mu}$v)' # Python 2.7
xlabel = 'Memory Capacity'

# Prepare confidence intervals for error bars
mean = np.mean(y)
level = 95

# TODO, sample size goes here
n = 12
alpha = 0.05
level = (1.0 - alpha) * 100

error = [confidence_interval(yy, sdsd, level, n) for yy, sdsd in zip(y, sd)]
print(error)
error = np.array(error).T

double_y = []

for i in y:
	double_y.append([i, i])
double_y = np.array(double_y).T

print(error)
print(double_y)

error = error - double_y
print(error)


plot_figure(x_start, y, xlabel, ylabel, error)
