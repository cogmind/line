from colormath.color_objects import sRGBColor, LabColor
from colormath.color_conversions import convert_color
from colormath.color_diff import delta_e_cie2000
from itertools import permutations, chain
import numpy as np

#
# CONVERT RGB STRING TO LAB COLOR
# (e.g. 'RED') to L*A*B* color via sRGB dictionary for 6 common colors.

def _convert_lab_from_rgb(rgb_string):

    color = {
        'BLUE': sRGBColor(0.0, 0.0, 1.0),
        'GREEN': sRGBColor(0.0, 1.0, 0.0),
        'YELLOW': sRGBColor(1.0, 1.0, 0.0),
        'RED': sRGBColor(1.0, 0.0, 0.0),
        'WHITE': sRGBColor(1.0, 1.0, 1.0),
        'BLACK': sRGBColor(0.0, 0.0, 0.0),
    }

    #print(rgb_string)
    lab_color = convert_color(color[rgb_string], LabColor, target_illuminant='D50')
    #print(lab_color)
    return lab_color

#
# COMPUTE Delta E for two different colors

def compute_delta_e(color_pair):
    ''' Compute delta E'''
    color_pair = (_convert_lab_from_rgb(color_pair[0]), _convert_lab_from_rgb(color_pair[1]))
    return delta_e_cie2000(*color_pair, Kl=1, Kc=1, Kh=1)


#
# COMPUTE Delta E for all possible combinations for a specific trial

def compute_mean_delta_e(color_array):
    color_array = list(chain(*permutations(color_array, 2)))
    #print(color_array)

    differences = []
    for c1, c2 in zip(color_array, color_array[1:]):
        #print('c1 ', c1)
        #print('c2 ', c2)
        differences.append(compute_delta_e((c1, c2)))
    mean_delta_e = np.mean(differences)
    return mean_delta_e


# TESTS
#print(compute_mean_delta_e(['RED', 'BLACK', 'GREEN']))
#print(compute_mean_delta_e(['RED', 'RED', 'GREEN']))
#print(compute_mean_delta_e(['RED', 'RED', 'RED']))
#print(compute_mean_delta_e(['WHITE', 'BLACK', 'GREEN']))
